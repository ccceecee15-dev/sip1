import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { ChevronRight, Home } from "lucide-react";

export function DrillBar() {
  return (
    <div className="px-6 py-3 border-b border-border/50 bg-background/50 backdrop-blur-sm">
      <Breadcrumb>
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/" className="text-muted-foreground hover:text-primary transition-colors flex items-center gap-1.5">
              <Home size={14} />
              <span>Tools & Reports</span>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator>
             <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/40" />
          </BreadcrumbSeparator>
          <BreadcrumbItem>
            <BreadcrumbLink href="/" className="text-muted-foreground hover:text-primary transition-colors">
              OTB Planning
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator>
             <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/40" />
          </BreadcrumbSeparator>
          <BreadcrumbItem>
            <BreadcrumbPage className="font-semibold text-primary">Dashboard</BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>
    </div>
  );
}
