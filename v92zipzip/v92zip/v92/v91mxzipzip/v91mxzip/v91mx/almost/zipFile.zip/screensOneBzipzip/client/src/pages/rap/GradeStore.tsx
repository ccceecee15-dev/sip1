import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { CompactFilterBar } from "@/components/filters/CompactFilterBar";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Building2, Info } from "lucide-react";
import { cn } from "@/lib/utils";

const REGIONS = ["All", "North", "South", "East", "West", "Central"];
const STORE_FORMATS = ["All", "Express", "Standard", "Flagship", "Travel Hub"];
const STORE_CLUSTERS = ["All", "Urban", "Suburban", "Rural", "Airport", "Station"];

const GRADE_OPTIONS = ["XS", "S", "M", "L"];

const FORMAT_DEFAULT_GRADES: Record<string, string> = {
  "Express": "S",
  "Standard": "M",
  "Flagship": "L",
  "Travel Hub": "L"
};

const generateMockData = () => {
  const stores = [
    { id: "STR001", name: "London Victoria", format: "Flagship", cluster: "Urban", region: "South" },
    { id: "STR002", name: "Manchester Piccadilly", format: "Flagship", cluster: "Urban", region: "North" },
    { id: "STR003", name: "Birmingham New Street", format: "Standard", cluster: "Urban", region: "Central" },
    { id: "STR004", name: "Edinburgh Waverley", format: "Standard", cluster: "Urban", region: "North" },
    { id: "STR005", name: "Glasgow Central", format: "Standard", cluster: "Urban", region: "North" },
    { id: "STR006", name: "Leeds Station", format: "Standard", cluster: "Urban", region: "North" },
    { id: "STR007", name: "Bristol Temple Meads", format: "Standard", cluster: "Suburban", region: "West" },
    { id: "STR008", name: "Liverpool Lime Street", format: "Standard", cluster: "Urban", region: "North" },
    { id: "STR009", name: "Heathrow T5", format: "Travel Hub", cluster: "Airport", region: "South" },
    { id: "STR010", name: "Gatwick South", format: "Travel Hub", cluster: "Airport", region: "South" },
    { id: "STR011", name: "Reading Station", format: "Express", cluster: "Suburban", region: "South" },
    { id: "STR012", name: "Oxford High Street", format: "Express", cluster: "Urban", region: "South" },
    { id: "STR013", name: "Cambridge Station", format: "Express", cluster: "Suburban", region: "East" },
    { id: "STR014", name: "York Station", format: "Express", cluster: "Suburban", region: "North" },
    { id: "STR015", name: "Newcastle Central", format: "Standard", cluster: "Urban", region: "North" },
    { id: "STR016", name: "Cardiff Central", format: "Standard", cluster: "Urban", region: "West" },
    { id: "STR017", name: "Southampton Central", format: "Express", cluster: "Suburban", region: "South" },
    { id: "STR018", name: "Nottingham Station", format: "Express", cluster: "Urban", region: "Central" },
    { id: "STR019", name: "Sheffield Station", format: "Express", cluster: "Urban", region: "North" },
    { id: "STR020", name: "Stansted Airport", format: "Travel Hub", cluster: "Airport", region: "East" },
  ];

  return stores.map(store => {
    const defaultGrade = FORMAT_DEFAULT_GRADES[store.format] || "M";
    const hasOverride = Math.random() < 0.15;
    const assignedGrade = hasOverride 
      ? GRADE_OPTIONS[Math.floor(Math.random() * GRADE_OPTIONS.length)]
      : defaultGrade;
    
    return {
      ...store,
      defaultGrade,
      assignedGrade,
      isOverride: assignedGrade !== defaultGrade
    };
  });
};

export default function GradeStore() {
  const [region, setRegion] = useState("all");
  const [storeFormat, setStoreFormat] = useState("all");
  const [storeCluster, setStoreCluster] = useState("all");
  const [data, setData] = useState(generateMockData);

  const handleGradeChange = (storeId: string, newGrade: string) => {
    setData(prev => prev.map(store => {
      if (store.id === storeId) {
        return {
          ...store,
          assignedGrade: newGrade,
          isOverride: newGrade !== store.defaultGrade
        };
      }
      return store;
    }));
  };

  const filteredData = data.filter(row => {
    if (region !== "all" && row.region.toLowerCase() !== region) return false;
    if (storeFormat !== "all" && row.format.toLowerCase().replace(/\s+/g, '-') !== storeFormat) return false;
    if (storeCluster !== "all" && row.cluster.toLowerCase() !== storeCluster) return false;
    return true;
  });

  const overrideCount = data.filter(s => s.isOverride).length;

  const TableHeader = ({ children, className = "" }: { children?: React.ReactNode, className?: string }) => (
    <th className={cn("px-3 py-2.5 text-[10px] font-bold uppercase tracking-wider border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 text-slate-600 dark:text-slate-400 text-center", className)}>
      {children}
    </th>
  );

  return (
    <MainLayout>
      <div className="space-y-6 animate-in fade-in duration-500">
        <div className="mb-2">
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">Grade Store</h1>
          <p className="text-sm text-slate-500 mt-1">Assign store grades for range planning</p>
        </div>

        <CompactFilterBar
          onApply={() => {}}
          onClear={() => {
            setRegion("all");
            setStoreFormat("all");
            setStoreCluster("all");
          }}
          fields={[
            { id: "region", label: "Region", value: region, onChange: setRegion, options: REGIONS.map(c => ({ value: c.toLowerCase(), label: c })) },
            { id: "store-format", label: "Store Format", value: storeFormat, onChange: setStoreFormat, options: STORE_FORMATS.map(c => ({ value: c.toLowerCase().replace(/\s+/g, '-'), label: c })) },
            { id: "store-cluster", label: "Store Cluster", value: storeCluster, onChange: setStoreCluster, options: STORE_CLUSTERS.map(c => ({ value: c.toLowerCase(), label: c })) },
          ]}
        />

        <div className="rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 p-4">
          <div className="flex items-start gap-2">
            <Info size={14} className="text-slate-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1">
              <p>All stores within a given format default to the largest store grade.</p>
              <p>Manual overrides are allowed at store level.</p>
              <p>Overrides apply only to RAP and do not affect SIP allocation.</p>
            </div>
          </div>
        </div>

        <Card className="relative overflow-hidden rounded-xl glass-card border shadow-lg">
          <CardHeader className="py-3 px-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
            <div className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-indigo-600/10 text-indigo-600">
                  <Building2 className="h-4.5 w-4.5" />
                </div>
                <div>
                  <CardTitle className="text-base font-bold tracking-tight text-slate-900 dark:text-slate-100">Store Grading</CardTitle>
                  <p className="text-[10px] text-slate-500 uppercase tracking-wider mt-0.5">Assign Grades by Store</p>
                </div>
              </div>
              <div className="flex items-center gap-6 text-xs">
                <div className="text-right">
                  <p className="text-slate-500">Total Stores</p>
                  <p className="font-bold text-slate-900 dark:text-slate-100 text-sm">{data.length}</p>
                </div>
                <div className="text-right">
                  <p className="text-slate-500">Overrides</p>
                  <p className={cn(
                    "font-bold text-sm",
                    overrideCount > 0 ? "text-amber-600" : "text-slate-900 dark:text-slate-100"
                  )}>
                    {overrideCount}
                  </p>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="w-full">
              <table className="w-full border-collapse">
                <thead className="sticky top-0 z-10">
                  <tr>
                    <TableHeader className="w-[100px] text-left">Store ID</TableHeader>
                    <TableHeader className="w-[200px] text-left">Store Name</TableHeader>
                    <TableHeader className="w-[120px]">Store Format</TableHeader>
                    <TableHeader className="w-[100px]">Cluster</TableHeader>
                    <TableHeader className="w-[140px]">Assigned Grade</TableHeader>
                    <TableHeader className="w-[100px]">Default Grade</TableHeader>
                    <TableHeader className="w-[100px]">Override</TableHeader>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredData.map((row) => (
                    <tr key={row.id} className="h-11 transition-colors hover:bg-slate-50/50">
                      <td className="px-3 py-2 text-[11px] font-medium border border-slate-100 text-left text-blue-600">
                        {row.id}
                      </td>
                      <td className="px-3 py-2 text-[11px] font-medium border border-slate-100 text-left text-slate-700 dark:text-slate-300">
                        {row.name}
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center text-slate-600">
                        {row.format}
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center text-slate-500">
                        {row.cluster}
                      </td>
                      <td className="px-3 py-2 border border-slate-100 text-center">
                        <Select 
                          value={row.assignedGrade} 
                          onValueChange={(value) => handleGradeChange(row.id, value)}
                        >
                          <SelectTrigger className={cn(
                            "h-7 w-20 text-xs font-medium mx-auto",
                            row.isOverride && "border-amber-400 bg-amber-50 dark:bg-amber-900/20"
                          )}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {GRADE_OPTIONS.map(grade => (
                              <SelectItem key={grade} value={grade} className="text-xs">
                                <span className={cn(
                                  "inline-flex items-center justify-center w-6 h-5 rounded text-[10px] font-bold mr-2",
                                  grade === "L" ? "bg-purple-100 text-purple-700" :
                                  grade === "M" ? "bg-blue-100 text-blue-700" :
                                  grade === "S" ? "bg-amber-100 text-amber-700" :
                                  "bg-slate-100 text-slate-600"
                                )}>
                                  {grade}
                                </span>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center">
                        <span className={cn(
                          "inline-flex items-center justify-center w-8 h-6 rounded text-[10px] font-bold",
                          row.defaultGrade === "L" ? "bg-purple-100 text-purple-700" :
                          row.defaultGrade === "M" ? "bg-blue-100 text-blue-700" :
                          row.defaultGrade === "S" ? "bg-amber-100 text-amber-700" :
                          "bg-slate-100 text-slate-600"
                        )}>
                          {row.defaultGrade}
                        </span>
                      </td>
                      <td className="px-3 py-2 border border-slate-100 text-center">
                        {row.isOverride ? (
                          <Badge variant="outline" className="text-[10px] font-medium bg-amber-100 text-amber-700 border-amber-200">
                            Yes
                          </Badge>
                        ) : (
                          <span className="text-[10px] text-slate-400">No</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <ScrollBar orientation="horizontal" />
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
