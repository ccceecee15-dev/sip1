import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { CompactFilterBar } from "@/components/filters/CompactFilterBar";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { LayoutList, Info, History, BarChart3 } from "lucide-react";
import { cn } from "@/lib/utils";
import productsData from "@/data/mock_products.json";

const MERCH_AREAS = ["All", "Main Floor", "Section A", "Section B"];
const CATEGORIES = ["All", "Stationery", "Travel", "Electronics", "Gifts", "Drinks Accessories", "Books", "Confectionery"];
const SEASONS = ["All", "SS26", "AW25", "SS25"];
const BRANDS = ["All", "WH Essentials", "Moleskine", "Lonely Planet", "Sony", "Cadbury"];

const GRADE_OPTIONS = ["High", "Medium", "Low"];

const generateMockData = () => {
  return productsData.map((product, index) => ({
    id: product.sku,
    sku: product.sku,
    name: product.name,
    category: product.category,
    season: index % 2 === 0 ? "SS26" : "AW25",
    reference: `REF-${product.sku}`,
    historicalSales: product.ly_sales,
    storeCoverage: Math.floor(Math.random() * 40) + 60, // 60-100%
    inRange: Math.random() > 0.1,
    grade: GRADE_OPTIONS[Math.floor(Math.random() * GRADE_OPTIONS.length)]
  }));
};

export default function RangeStyle() {
  const [merchArea, setMerchArea] = useState("all");
  const [category, setCategory] = useState("all");
  const [season, setSeason] = useState("all");
  const [brand, setBrand] = useState("all");
  const [data, setData] = useState(generateMockData);

  const handleInRangeChange = (id: string, checked: boolean) => {
    setData(prev => prev.map(item => 
      item.id === id ? { ...item, inRange: checked } : item
    ));
  };

  const handleGradeChange = (id: string, value: string) => {
    setData(prev => prev.map(item => 
      item.id === id ? { ...item, grade: value } : item
    ));
  };

  const filteredData = data.filter(row => {
    if (category !== "all" && row.category.toLowerCase().replace(/\s+/g, '-') !== category) return false;
    if (season !== "all" && row.season.toLowerCase() !== season) return false;
    return true;
  });

  const TableHeader = ({ children, className = "" }: { children?: React.ReactNode, className?: string }) => (
    <th className={cn("px-3 py-2.5 text-[10px] font-bold uppercase tracking-wider border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 text-slate-600 dark:text-slate-400 text-center", className)}>
      {children}
    </th>
  );

  return (
    <MainLayout>
      <div className="space-y-6 animate-in fade-in duration-500">
        <div className="mb-2">
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">Range Style</h1>
          <p className="text-sm text-slate-500 mt-1">Select styles to include in the range</p>
        </div>

        <CompactFilterBar
          onApply={() => {}}
          onClear={() => {
            setMerchArea("all");
            setCategory("all");
            setSeason("all");
            setBrand("all");
          }}
          fields={[
            { id: "merch-area", label: "Merch Area", value: merchArea, onChange: setMerchArea, options: MERCH_AREAS.map(c => ({ value: c.toLowerCase().replace(/\s+/g, '-'), label: c })) },
            { id: "category", label: "Category", value: category, onChange: setCategory, options: CATEGORIES.map(c => ({ value: c.toLowerCase().replace(/\s+/g, '-'), label: c })) },
            { id: "season", label: "Season", value: season, onChange: setSeason, options: SEASONS.map(c => ({ value: c.toLowerCase(), label: c })) },
            { id: "brand", label: "Brand", value: brand, onChange: setBrand, options: BRANDS.map(c => ({ value: c.toLowerCase().replace(/\s+/g, '-'), label: c })) },
          ]}
        />

        <div className="rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 p-4">
          <div className="flex items-start gap-2">
            <Info size={14} className="text-slate-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1">
              <p>Grading size and store grades are already defined.</p>
              <p>Style selection determines eligibility only.</p>
              <p>Facings and presentation are set in the next step.</p>
            </div>
          </div>
        </div>

        <Card className="relative overflow-hidden rounded-xl glass-card border shadow-lg">
          <CardHeader className="py-3 px-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
            <div className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-blue-600/10 text-blue-600">
                  <LayoutList className="h-4.5 w-4.5" />
                </div>
                <div>
                  <CardTitle className="text-base font-bold tracking-tight text-slate-900 dark:text-slate-100">Style Selection</CardTitle>
                  <p className="text-[10px] text-slate-500 uppercase tracking-wider mt-0.5">Define Style Eligibility & Grade</p>
                </div>
              </div>
              <div className="flex items-center gap-6 text-xs">
                <div className="text-right">
                  <p className="text-slate-500">Total Styles</p>
                  <p className="font-bold text-slate-900 dark:text-slate-100 text-sm">{data.length}</p>
                </div>
                <div className="text-right">
                  <p className="text-slate-500">In Range</p>
                  <p className="font-bold text-emerald-600 text-sm">{data.filter(i => i.inRange).length}</p>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="w-full">
              <table className="w-full border-collapse">
                <thead className="sticky top-0 z-10">
                  <tr>
                    <TableHeader className="w-[100px] text-left">Style ID</TableHeader>
                    <TableHeader className="w-[200px] text-left">Description</TableHeader>
                    <TableHeader className="w-[120px]">Category</TableHeader>
                    <TableHeader className="w-[80px]">Season</TableHeader>
                    <TableHeader className="w-[100px]">Reference</TableHeader>
                    <TableHeader className="w-[120px]">Hist. Sales</TableHeader>
                    <TableHeader className="w-[100px]">Coverage</TableHeader>
                    <TableHeader className="w-[100px]">In Range</TableHeader>
                    <TableHeader className="w-[140px]">Style Grade</TableHeader>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredData.map((row) => (
                    <tr key={row.id} className={cn(
                      "h-11 transition-colors hover:bg-slate-50/50",
                      !row.inRange && "bg-slate-50/30 opacity-75"
                    )}>
                      <td className="px-3 py-2 text-[11px] font-medium border border-slate-100 text-left text-blue-600">
                        {row.sku}
                      </td>
                      <td className="px-3 py-2 text-[11px] font-medium border border-slate-100 text-left text-slate-700 dark:text-slate-300">
                        {row.name}
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center text-slate-500">
                        {row.category}
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center text-slate-500">
                        {row.season}
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center text-slate-400 font-mono">
                        {row.reference}
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center tabular-nums text-slate-600">
                        <div className="flex items-center justify-center gap-1">
                          <History size={10} className="text-slate-400" />
                          {row.historicalSales.toLocaleString()}
                        </div>
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center tabular-nums">
                        <div className="flex items-center justify-center gap-1 text-slate-600">
                          <BarChart3 size={10} className="text-slate-400" />
                          {row.storeCoverage}%
                        </div>
                      </td>
                      <td className="px-3 py-2 border border-slate-100 text-center">
                        <Switch 
                          checked={row.inRange} 
                          onCheckedChange={(checked) => handleInRangeChange(row.id, checked)}
                          className="data-[state=checked]:bg-emerald-500 scale-75"
                        />
                      </td>
                      <td className="px-3 py-2 border border-slate-100 text-center">
                        <Select 
                          value={row.grade} 
                          onValueChange={(value) => handleGradeChange(row.id, value)}
                          disabled={!row.inRange}
                        >
                          <SelectTrigger className={cn(
                            "h-7 w-28 text-[10px] font-semibold mx-auto uppercase",
                            !row.inRange && "opacity-50"
                          )}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {GRADE_OPTIONS.map(option => (
                              <SelectItem key={option} value={option} className="text-[10px] font-semibold uppercase">
                                {option}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <ScrollBar orientation="horizontal" />
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
