import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { CompactFilterBar } from "@/components/filters/CompactFilterBar";
import { LayoutGrid, Info, Box } from "lucide-react";
import { cn } from "@/lib/utils";
import productsData from "@/data/mock_products.json";

const MERCH_AREAS = ["All", "Main Floor", "Section A", "Section B"];
const CATEGORIES = ["All", "Stationery", "Travel", "Electronics", "Gifts", "Drinks Accessories", "Books", "Confectionery"];
const SEASONS = ["All", "SS26", "AW25", "SS25"];
const STORE_FORMATS = ["All", "Express", "Standard", "Flagship", "Travel Hub"];
const STORE_GRADES = ["All", "XS", "S", "M", "L"];

const generateMockData = () => {
  const grades = ["XS", "S", "M", "L"];
  const data: any[] = [];
  
  // Use first 10 products to keep table manageable but realistic
  productsData.slice(0, 10).forEach((product) => {
    grades.forEach((grade) => {
      const baseFacings = grade === "L" ? 4 : grade === "M" ? 2 : 1;
      const basePresentation = baseFacings * (Math.floor(Math.random() * 3) + 2);
      
      data.push({
        id: `${product.sku}-${grade}`,
        sku: product.sku,
        name: product.name,
        grade,
        facings: baseFacings,
        presentationQty: basePresentation,
        fixtureType: "Shelf",
        capacityHint: Math.floor(basePresentation * 1.5)
      });
    });
  });
  
  return data;
};

export default function DetermineFacingsPresentation() {
  const [merchArea, setMerchArea] = useState("all");
  const [category, setCategory] = useState("all");
  const [season, setSeason] = useState("all");
  const [storeFormat, setStoreFormat] = useState("all");
  const [storeGrade, setStoreGrade] = useState("all");
  const [data, setData] = useState(generateMockData);

  const handleValueChange = (id: string, field: "facings" | "presentationQty", value: string) => {
    const numValue = parseInt(value) || 0;
    setData(prev => prev.map(item => 
      item.id === id ? { ...item, [field]: numValue } : item
    ));
  };

  const filteredData = data.filter(row => {
    if (category !== "all" && row.name.toLowerCase().includes(category)) return false; // Simple mock filter
    if (storeGrade !== "all" && row.grade.toLowerCase() !== storeGrade) return false;
    return true;
  });

  const TableHeader = ({ children, className = "" }: { children?: React.ReactNode, className?: string }) => (
    <th className={cn("px-3 py-2.5 text-[10px] font-bold uppercase tracking-wider border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 text-slate-600 dark:text-slate-400 text-center", className)}>
      {children}
    </th>
  );

  return (
    <MainLayout>
      <div className="space-y-6 animate-in fade-in duration-500">
        <div className="mb-2">
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">Determine Facings & Presentation</h1>
          <p className="text-sm text-slate-500 mt-1">Define minimum on-shelf presence by store grade</p>
        </div>

        <CompactFilterBar
          onApply={() => {}}
          onClear={() => {
            setMerchArea("all");
            setCategory("all");
            setSeason("all");
            setStoreFormat("all");
            setStoreGrade("all");
          }}
          fields={[
            { id: "merch-area", label: "Merch Area", value: merchArea, onChange: setMerchArea, options: MERCH_AREAS.map(c => ({ value: c.toLowerCase().replace(/\s+/g, '-'), label: c })) },
            { id: "category", label: "Category", value: category, onChange: setCategory, options: CATEGORIES.map(c => ({ value: c.toLowerCase().replace(/\s+/g, '-'), label: c })) },
            { id: "season", label: "Season", value: season, onChange: setSeason, options: SEASONS.map(c => ({ value: c.toLowerCase(), label: c })) },
            { id: "store-format", label: "Store Format", value: storeFormat, onChange: setStoreFormat, options: STORE_FORMATS.map(c => ({ value: c.toLowerCase().replace(/\s+/g, '-'), label: c })) },
            { id: "store-grade", label: "Store Grade", value: storeGrade, onChange: setStoreGrade, options: STORE_GRADES.map(c => ({ value: c.toLowerCase(), label: c })) },
          ]}
        />

        <div className="rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 p-4">
          <div className="flex items-start gap-2">
            <Info size={14} className="text-slate-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1">
              <p>Only styles marked In Range are shown.</p>
              <p>Store grades are inherited from Grade Store.</p>
              <p>These rules feed SIP and do not plan quantities.</p>
            </div>
          </div>
        </div>

        <Card className="relative overflow-hidden rounded-xl glass-card border shadow-lg">
          <CardHeader className="py-3 px-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
            <div className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-emerald-600/10 text-emerald-600">
                  <LayoutGrid className="h-4.5 w-4.5" />
                </div>
                <div>
                  <CardTitle className="text-base font-bold tracking-tight text-slate-900 dark:text-slate-100">Facings & Presentation Rules</CardTitle>
                  <p className="text-[10px] text-slate-500 uppercase tracking-wider mt-0.5">Define Minimum Presence Rules</p>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="w-full">
              <table className="w-full border-collapse">
                <thead className="sticky top-0 z-10">
                  <tr>
                    <TableHeader className="w-[100px] text-left">Style ID</TableHeader>
                    <TableHeader className="w-[200px] text-left">Description</TableHeader>
                    <TableHeader className="w-[100px]">Store Grade</TableHeader>
                    <TableHeader className="w-[120px]">Facings</TableHeader>
                    <TableHeader className="w-[120px]">Presentation Qty</TableHeader>
                    <TableHeader className="w-[120px]">Fixture Type</TableHeader>
                    <TableHeader className="w-[100px]">Cap. Hint</TableHeader>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredData.map((row) => (
                    <tr key={row.id} className="h-11 transition-colors hover:bg-slate-50/50">
                      <td className="px-3 py-2 text-[11px] font-medium border border-slate-100 text-left text-blue-600">
                        {row.sku}
                      </td>
                      <td className="px-3 py-2 text-[11px] font-medium border border-slate-100 text-left text-slate-700 dark:text-slate-300">
                        {row.name}
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center">
                        <span className={cn(
                          "inline-flex items-center justify-center w-8 h-6 rounded text-[10px] font-bold",
                          row.grade === "L" ? "bg-purple-100 text-purple-700" :
                          row.grade === "M" ? "bg-blue-100 text-blue-700" :
                          row.grade === "S" ? "bg-amber-100 text-amber-700" :
                          "bg-slate-100 text-slate-600"
                        )}>
                          {row.grade}
                        </span>
                      </td>
                      <td className="px-3 py-2 border border-slate-100 text-center">
                        <Input
                          type="number"
                          value={row.facings}
                          onChange={(e) => handleValueChange(row.id, "facings", e.target.value)}
                          className="h-7 w-20 text-center text-xs font-medium mx-auto tabular-nums"
                          min={0}
                        />
                      </td>
                      <td className="px-3 py-2 border border-slate-100 text-center">
                        <Input
                          type="number"
                          value={row.presentationQty}
                          onChange={(e) => handleValueChange(row.id, "presentationQty", e.target.value)}
                          className="h-7 w-20 text-center text-xs font-medium mx-auto tabular-nums"
                          min={0}
                        />
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center text-slate-500">
                        <div className="flex items-center justify-center gap-1">
                          <Box size={10} className="text-slate-400" />
                          {row.fixtureType}
                        </div>
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center tabular-nums text-slate-400">
                        {row.capacityHint}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <ScrollBar orientation="horizontal" />
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
