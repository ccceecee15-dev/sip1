import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { CompactFilterBar } from "@/components/filters/CompactFilterBar";
import { Target, Info } from "lucide-react";
import { cn } from "@/lib/utils";

const MERCH_AREAS = ["All", "Main Floor", "Section A", "Section B"];
const CATEGORIES = ["All", "Stationery", "Travel", "Electronics", "Gifts"];
const SEASONS = ["All", "SS26", "AW25", "SS25"];
const DISPLAY_BLOCKS = ["All", "Front Wall", "Mid Gondola", "Back Wall", "Checkout"];

const GRADE_BANDS = ["XS", "S", "M", "L"];

const generateMockData = () => {
  const displayBlocks = ["Front Wall", "Mid Gondola", "Back Wall", "Checkout"];
  const data: Array<{
    id: number;
    displayBlock: string;
    gradeBand: string;
    targetSkuCount: number;
    historicalAvgSkuCount: number;
    percentOfTotal: number;
  }> = [];
  
  let id = 1;
  displayBlocks.forEach((block) => {
    GRADE_BANDS.forEach((grade) => {
      const baseCount = block === "Front Wall" ? 45 : 
                       block === "Mid Gondola" ? 35 : 
                       block === "Back Wall" ? 28 : 18;
      
      const gradeMultiplier = grade === "L" ? 1.0 : 
                             grade === "M" ? 0.75 : 
                             grade === "S" ? 0.5 : 0.3;
      
      const targetSkuCount = Math.round(baseCount * gradeMultiplier);
      const historicalAvgSkuCount = Math.round(targetSkuCount * (0.85 + Math.random() * 0.3));
      
      data.push({
        id: id++,
        displayBlock: block,
        gradeBand: grade,
        targetSkuCount,
        historicalAvgSkuCount,
        percentOfTotal: 0
      });
    });
  });
  
  const totalTarget = data.reduce((sum, row) => sum + row.targetSkuCount, 0);
  data.forEach(row => {
    row.percentOfTotal = Math.round((row.targetSkuCount / totalTarget) * 100 * 10) / 10;
  });
  
  return data;
};

export default function DetermineGradingSize() {
  const [merchArea, setMerchArea] = useState("all");
  const [category, setCategory] = useState("all");
  const [season, setSeason] = useState("all");
  const [displayBlock, setDisplayBlock] = useState("all");
  const [data, setData] = useState(generateMockData);

  const totalSkuBudget = 350;
  const totalTargetCount = data.reduce((sum, row) => sum + row.targetSkuCount, 0);
  const remaining = totalSkuBudget - totalTargetCount;

  const handleTargetChange = (id: number, value: string) => {
    const numValue = parseInt(value) || 0;
    setData(prev => {
      const updated = prev.map(row => 
        row.id === id ? { ...row, targetSkuCount: numValue } : row
      );
      const total = updated.reduce((sum, row) => sum + row.targetSkuCount, 0);
      return updated.map(row => ({
        ...row,
        percentOfTotal: total > 0 ? Math.round((row.targetSkuCount / total) * 100 * 10) / 10 : 0
      }));
    });
  };

  const filteredData = data.filter(row => {
    if (displayBlock !== "all" && !row.displayBlock.toLowerCase().includes(displayBlock.replace(/-/g, ' '))) return false;
    return true;
  });

  const TableHeader = ({ children, className = "" }: { children?: React.ReactNode, className?: string }) => (
    <th className={cn("px-3 py-2.5 text-[10px] font-bold uppercase tracking-wider border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 text-slate-600 dark:text-slate-400 text-center", className)}>
      {children}
    </th>
  );

  return (
    <MainLayout>
      <div className="space-y-6 animate-in fade-in duration-500">
        <div className="mb-2">
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">Determine Grading Size</h1>
          <p className="text-sm text-slate-500 mt-1">Define target SKU counts by display block and grade</p>
        </div>

        <CompactFilterBar
          onApply={() => {}}
          onClear={() => {
            setMerchArea("all");
            setCategory("all");
            setSeason("all");
            setDisplayBlock("all");
          }}
          fields={[
            { id: "merch-area", label: "Merch Area", value: merchArea, onChange: setMerchArea, options: MERCH_AREAS.map(c => ({ value: c.toLowerCase().replace(/\s+/g, '-'), label: c })) },
            { id: "category", label: "Category", value: category, onChange: setCategory, options: CATEGORIES.map(c => ({ value: c.toLowerCase().replace(/\s+/g, '-'), label: c })) },
            { id: "season", label: "Season", value: season, onChange: setSeason, options: SEASONS.map(c => ({ value: c.toLowerCase().replace(/\s+/g, '-'), label: c })) },
            { id: "display-block", label: "Display Block", value: displayBlock, onChange: setDisplayBlock, options: DISPLAY_BLOCKS.map(c => ({ value: c.toLowerCase().replace(/\s+/g, '-'), label: c })) },
          ]}
        />

        <div className="rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 p-4">
          <div className="flex items-start gap-2">
            <Info size={14} className="text-slate-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1">
              <p>All stores within a given format default to the largest store grade.</p>
              <p>Store-level grading overrides (if any) are handled in Grade Store.</p>
              <p>Capacity and fixture constraints are applied downstream.</p>
            </div>
          </div>
        </div>

        <Card className="relative overflow-hidden rounded-xl glass-card border shadow-lg">
          <CardHeader className="py-3 px-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
            <div className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-purple-600/10 text-purple-600">
                  <Target className="h-4.5 w-4.5" />
                </div>
                <div>
                  <CardTitle className="text-base font-bold tracking-tight text-slate-900 dark:text-slate-100">Grading Size</CardTitle>
                  <p className="text-[10px] text-slate-500 uppercase tracking-wider mt-0.5">Display Block × Grade Band</p>
                </div>
              </div>
              <div className="flex items-center gap-6 text-xs">
                <div className="text-right">
                  <p className="text-slate-500">Total SKU Budget</p>
                  <p className="font-bold text-slate-900 dark:text-slate-100 text-sm">{totalSkuBudget}</p>
                </div>
                <div className="text-right">
                  <p className="text-slate-500">Allocated</p>
                  <p className="font-bold text-slate-900 dark:text-slate-100 text-sm">{totalTargetCount}</p>
                </div>
                <div className="text-right">
                  <p className="text-slate-500">Remaining</p>
                  <p className={cn(
                    "font-bold text-sm",
                    remaining < 0 ? "text-red-600" : remaining === 0 ? "text-emerald-600" : "text-amber-600"
                  )}>
                    {remaining > 0 ? `+${remaining}` : remaining}
                  </p>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="w-full">
              <table className="w-full border-collapse">
                <thead className="sticky top-0 z-10">
                  <tr>
                    <TableHeader className="w-[180px] text-left">Display Block</TableHeader>
                    <TableHeader className="w-[100px]">Grade Band</TableHeader>
                    <TableHeader className="w-[140px]">Target SKU Count</TableHeader>
                    <TableHeader className="w-[140px]">Hist. Avg SKU Count</TableHeader>
                    <TableHeader className="w-[100px]">% of Total</TableHeader>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredData.map((row) => (
                    <tr key={row.id} className="h-11 transition-colors hover:bg-slate-50/50">
                      <td className="px-3 py-2 text-[11px] font-medium border border-slate-100 text-left text-slate-700 dark:text-slate-300">
                        {row.displayBlock}
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center">
                        <span className={cn(
                          "inline-flex items-center justify-center w-8 h-6 rounded text-[10px] font-bold",
                          row.gradeBand === "L" ? "bg-purple-100 text-purple-700" :
                          row.gradeBand === "M" ? "bg-blue-100 text-blue-700" :
                          row.gradeBand === "S" ? "bg-amber-100 text-amber-700" :
                          "bg-slate-100 text-slate-600"
                        )}>
                          {row.gradeBand}
                        </span>
                      </td>
                      <td className="px-3 py-2 border border-slate-100 text-center">
                        <Input
                          type="number"
                          value={row.targetSkuCount}
                          onChange={(e) => handleTargetChange(row.id, e.target.value)}
                          className="h-7 w-20 text-center text-xs font-medium mx-auto tabular-nums"
                          min={0}
                        />
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center tabular-nums text-slate-500">
                        {row.historicalAvgSkuCount}
                      </td>
                      <td className="px-3 py-2 text-[11px] border border-slate-100 text-center tabular-nums text-slate-600 dark:text-slate-400">
                        {row.percentOfTotal}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <ScrollBar orientation="horizontal" />
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
